This is a simple To-Do List application for Android. The app allows users to create a list of tasks they need to complete and mark them as completed when done.

Features
Display a list of to-do items
Add new items to the list
Mark items as completed
Remove items from the list

Usage
On the main screen, you will see a list of to-do items.
To add a new item, enter the task description in the "Enter a new item" field and click the "Add Item" button.
To mark an item as completed, click on the checkbox next to the item.
To remove an item from the list, swipe left on the item or long-press on the item and confirm the deletion.

Technologies Used
Java programming language
Android SDK
XML for layout design

Dari Charles (10973917)

cdar@st.ug.edu.gh