This is a simple calculator app developed for Android devices using Java and XML. The app provides basic arithmetic operations and memory functionality.Features

Addition, subtraction, multiplication, and division operations
Memory storage and retrieval (MC, M+, M-, MR buttons)
Clearing the current input (C button)
Deleting the last digit (⌫ button)
Percentage calculation (% button)

Usage
Launch the Calculator app on your Android device.
Use the numeric buttons (0-9) to enter numbers.
Use the operation buttons (+, -, ×, ÷) to perform arithmetic operations.
Press the = button to calculate the result.
Use the % button to calculate the percentage of a number.
Press the C button to clear the current input.
Press the ⌫ button to delete the last digit.
Use the memory buttons (MC, M+, M-, MR) to store and retrieve values from memory.

Dari Charles (10973917)

cdari@st.ug.edu.gh