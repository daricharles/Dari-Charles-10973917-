package charlesdari.com.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private double memory = 0.0;
//    Button digitButton = findViewById(R.id.digitButton);

    TextView result, solution;
    MaterialButton buttonmc, buttonmp, buttonmn, buttonmr;
    MaterialButton buttonca, buttond, buttont, buttondel;
    MaterialButton button7, button8, button9, buttonm;
    MaterialButton button4, button5, button6, buttonp;
    MaterialButton button1, button2, button3, buttonper;
    MaterialButton buttondot, button0, buttoneq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = findViewById(R.id.result);
        solution = findViewById(R.id.solution);

        // Get references to the necessary buttons
//        buttonper percentButton = findViewById(R.id.button_per);
//        buttonmc mcButton = findViewById(R.id.button_mc);
//        buttonmp mPlusButton = findViewById(R.id.button_mp);
//        buttonmn mMinusButton = findViewById(R.id.button_mm);
//        buttonmr mrButton = findViewById(R.id.button_mr);

        assignId(buttonmc,R.id.button_mc);
        assignId(buttonmp,R.id.button_mp);
        assignId(buttonmr,R.id.button_mr);
        assignId(buttonca,R.id.button_ca);
        assignId(buttond,R.id.button_d);
        assignId(buttont,R.id.button_t);
        assignId(buttonmn,R.id.button_mm);
        assignId(buttondel,R.id.button_del);
        assignId(button7,R.id.button_7);
        assignId(button8,R.id.button_8);
        assignId(button9,R.id.button_9);
        assignId(buttonm,R.id.button_m);
        assignId(button4,R.id.button_4);
        assignId(button5,R.id.button_5);
        assignId(button6,R.id.button_6);
        assignId(buttonp,R.id.button_p);
        assignId(button1,R.id.button_1);
        assignId(button2,R.id.button_2);
        assignId(button3,R.id.button_3);
        assignId(buttonper,R.id.button_per);
        assignId(buttondot,R.id.button_dot);
        assignId(button0,R.id.button_0);
        assignId(buttoneq,R.id.button_eq);
    }

    void assignId(MaterialButton btn,int id){
        btn=findViewById(id);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        MaterialButton button = (MaterialButton) view;
        String buttonText = button.getText().toString();
        String dataToCalculate = solution.getText().toString();

        if (buttonText.equals("%")){
            String currentResult = result.getText().toString();
            double result = Double.parseDouble(currentResult) / 100;
            solution.setText(String.valueOf(result));
            return;
        }

        if (buttonText.equals("mc")){
            memory = 0.0;
            return;
        }

        if (buttonText.equals("m+")){
            String currentResult = result.getText().toString();
            double value = Double.parseDouble(currentResult);
            memory += value;
            return;
        }

        if (buttonText.equals("m-")){
            String currentResult = result.getText().toString();
            double value = Double.parseDouble(currentResult);
            memory -= value;
            return;
        }

        if (buttonText.equals("mr")){
            result.setText(String.valueOf(memory));
            return;
        }

        if (buttonText.equals("c")){
            solution.setText("");
            result.setText("0");
            return;
        }
        if (buttonText.equals("=")){
            solution.setText(result.getText());
            return;
        }

//        String currentText = solution.getText().toString();
//        if (currentText.length() < 8) {
//            String buttonView = ((Button) v).getText().toString();
//            String newText = currentText + buttonText;
//            solution.setText(newText);
//        }

        if (buttonText.equals("⌫")){
            dataToCalculate = dataToCalculate.substring(0, dataToCalculate.length()-1);
        }else {
            dataToCalculate = dataToCalculate + buttonText;
        }

        solution.setText(dataToCalculate);
        String finalResult = getResult(dataToCalculate);
        if (!finalResult.equals("Err")){
            result.setText(finalResult);
        }

    }


    String getResult (String data){
        try {
            data = data.replace("×", "*").replace("÷", "/").replace("−", "-");

            Context context = Context.enter();
            context.setOptimizationLevel(-1);
            Scriptable scriptable = context.initStandardObjects();
            String finalResult = context.evaluateString(scriptable, data, "Javascript", 1, null).toString();
            if (finalResult.endsWith(".0")){
                finalResult = finalResult.replace(".0", "");
            }
            return finalResult;
        }catch (Exception e){
            return "Err";
        }
    }
}